# How to Update Casino Audit Content Using config.json

This guide explains how the casino-level content is controlled through a single file: `config.json`.

Instead of editing multiple `.mdx` pages directly, you can update the dashboard and executive summary by changing the values in this config file. The page templates already read from it.

## Where the file lives

```bash
docs/casinos/duel/config.json
```

This is the main config for the casino-level pages, including:
- Dashboard
- Executive Summary

> [! Individual game reports, like Plinko, Dice, or Crash, each have their own separate config.json inside the game folder.]

## File structure
The casino-level config file is organized into these top-level sections:

config.json
├── name, domain, auditId, certDate, nextReview
├── status, certifiedBy, intro
├── stats
├── architecture
├── timeline
├── verdicts
├── games
└── transparency

Each section controls a visible part of either the Dashboard page or the Executive Summary page.

### Casino identity

```json
{
  "name": "Duel.com",
  "domain": "duel.com",
  "auditId": "PF-2026-001",
  "certDate": "Feb 12, 2026",
  "nextReview": "Feb 2027",
  "status": "CERTIFIED",
  "certifiedBy": "ProvablyFair.org",
  "intro": "Independent verification of RNG integrity, live game parity, RTP convergence, and fairness integrity across 8 games."
}
```

- name → casino name shown on shared page components
- domain → casino domain
- auditId → audit reference ID
- certDate → certification date shown in the banner
- nextReview → next review date
- status → certification status
- certifiedBy → certifying organization
- intro → short summary text shown near the top of the dashboard

### Dashboard intro and shared summary stats
These values can be seen in the Audit Verdict section of the dashboard and the validation approach overview of the executive summary.

```json
"stats": {
  "liveBetsVerified": "30,742",
  "simulationRounds": "80,000,000+",
  "integrityChecks": "120",
  "gamesValidated": "8 / 8"
}
```
- liveBetsVerified → total live bets verified
- simulationRounds → total number of simulation rounds
- integrityChecks → total integrity checks performed
- gamesValidated → number of validated games

### Dashboard - Audit Verdict
The main dashboard verdict table fetches its content from verdicts array.

```json
"verdicts": [
  {
    "number": "01",
    "area": "Determinism",
    "status": "pass",
    "evidence": "HMAC-SHA256 with rejection sampling. Nonce starts at 0, increments by 1, never reused. Player controls client seed. 100% deterministic."
  },
  {
    "number": "02",
    "area": "RNG Integrity",
    "status": "pass",
    "evidence": "No external entropy sources. Chi-squared uniformity: p = 0.472 across 980K simulated rounds. Rejection sampling eliminates modulo bias."
  }
]
```
- number → row number shown in the table
- area → control area being evaluated
- status → verdict status
- evidence → supporting summary text

Each object represents one table row, you can add, remove or edit rows as needed. 
Use the expected status strings used by the component, such as;
- pass
- fail

### Dashboard - Game validation matrix
The game validation matrix and the game cards in the executive summary page fetch their content from the games array.

```json
"games": [
  {
    "name": "Plinko",
    "slug": "plinko",
    "icon": "plinko",
    "rngModel": "HMAC-SHA256",
    "parity": "1,009 bets",
    "rtp": "10M sim",
    "integrity": "15 checks",
    "scope": "400 seed sessions",
    "status": "pass"
  }
]
```
- name → game name shown to users
- slug → used for linking to the game page
- icon → icon key used by the UI
- rngModel → RNG model label
- parity → parity testing summary
- rtp → RTP simulation summary
- integrity → integrity testing summary
- scope → validation scope summary
- status → per-game certification result

### Dashboard - Audit Timeline
The dashboard audit timeline fetches its content from the timeline array.
```json
"timeline": [
  { "title": "Initiated",         "date": "Jan 28" },
  { "title": "Data Capture",      "date": "Feb 4"  },
  { "title": "Parity Testing",    "date": "Feb 6"  },
  { "title": "RTP Simulation",    "date": "Feb 8"  },
  { "title": "Integrity Testing", "date": "Feb 12" },
  { "title": "Certification",     "date": "Feb 12" }
]
```
- title → timeline milestone name
- date → milestone date
Each object is one timeline step. Add, remove, or reorder them as needed.

### Dashboard - Transparency and Verification

The dashboard transparency section uses:

```json
"transparency": {
  "auditRepoUrl": "https://github.com/provablyfair/audits",
  "datasetUrl": "https://github.com/provablyfair/audits/datasets",
  "verifierUrl": "https://provablyfair.org/verify/duel",
  "commitHash": "fa913ab94883d06950d3c63bbb7007f927648131",
  "frameworkVersion": "ProvablyFair v1.0"
}
```

- auditRepoUrl → audit repository link
- datasetUrl → dataset link
- verifierUrl → public verifier link
-commitHash → audited commit reference
- frameworkVersion → framework/version label

Make sure all URLs are valid and public if the page is meant to be externally accessible.